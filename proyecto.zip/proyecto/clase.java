public class clase {
}
