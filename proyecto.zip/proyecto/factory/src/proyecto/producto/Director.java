package proyecto.producto;
public class Director { public void hacerPcBasica(ProductoBuilder b){ b.reset(); b.setId(1); b.setNombre("PC Basica"); b.setPrecio(1200000); b.setDescripcion("Intel i3 | 8GB | SSD 256GB"); } }
