package proyecto.negocio;
public class Reporte { private TipoReporte tipo; private String contenido; public Reporte(TipoReporte t,String c){this.tipo=t;this.contenido=c;} public TipoReporte getTipo(){return tipo;} public String getContenido(){return contenido;} }
