package proyecto.negocio;
import java.util.ArrayList; import java.util.List;
public class Venta { private int id; private Usuario usuario; private List<DetalleVenta> detalles = new ArrayList<>(); public Venta(){} public Venta(int id, Usuario u){this.id=id;this.usuario=u;} public int getId(){return id;} public Usuario getUsuario(){return usuario;} public List<DetalleVenta> getDetalles(){return detalles;} public void setId(int id){this.id=id;} public void setUsuario(Usuario u){this.usuario=u;} public void agregarDetalle(DetalleVenta d){detalles.add(d);} }
