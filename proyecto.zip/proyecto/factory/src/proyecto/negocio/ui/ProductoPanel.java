package proyecto.negocio.ui;
import javax.swing.*; import javax.swing.table.DefaultTableModel; import java.awt.*; import java.sql.*; import java.util.function.Supplier; import factory.database.Database; import proyecto.producto.Producto;
public class ProductoPanel extends JPanel {
    private final Supplier<factory.database.Database> dbSupplier;
    private JTable table;

    public ProductoPanel(Supplier<factory.database.Database> dbSupplier) {
        this.dbSupplier = dbSupplier;
        setLayout(new BorderLayout());
        table = new JTable();
        add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel s = new JPanel();
        JButton btn = new JButton("Actualizar");
        btn.addActionListener(e -> load());
        s.add(btn);
        add(s, BorderLayout.SOUTH);
        load();
    }

    private void load() {
        DefaultTableModel m = new DefaultTableModel(new Object[]{"ID", "Nombre", "Precio", "Descripcion"}, 0);
        factory.database.Database db = dbSupplier.get();
        if (db == null) {
            table.setModel(m);
            return;
        }
        try (Connection c = db.connect(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT id,nombre,precio,descripcion FROM productos")) {
            while (rs.next()) m.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getDouble(3), rs.getString(4)});
            table.setModel(m);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            table.setModel(m);
        }
    }
}
