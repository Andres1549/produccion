package proyecto.negocio.ui;
import javax.swing.*; import javax.swing.table.DefaultTableModel; import java.awt.*; import java.sql.*; import java.util.function.Supplier; import factory.database.Database;
public class VentaPanel extends JPanel {
    private final Supplier<factory.database.Database> dbSupplier;
    private JTable table;

    public VentaPanel(Supplier<factory.database.Database> dbSupplier) {
        this.dbSupplier = dbSupplier;
        setLayout(new BorderLayout());
        table = new JTable();
        add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel s = new JPanel();
        JButton btn = new JButton("Actualizar");
        btn.addActionListener(e -> load());
        s.add(btn);
        add(s, BorderLayout.SOUTH);
        load();
    }

    private void load() {
        DefaultTableModel m = new DefaultTableModel(new Object[]{"ID", "Usuario", "#Items"}, 0);
        factory.database.Database db = dbSupplier.get();
        if (db == null) {
            table.setModel(m);
            return;
        }
        try (Connection c = db.connect(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT v.id, u.nombre, COUNT(d.producto_id) as items FROM ventas v LEFT JOIN usuarios u ON v.usuario_id = u.id LEFT JOIN detalles d ON d.venta_id = v.id GROUP BY v.id, u.nombre")) {
            while (rs.next()) m.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getInt(3)});
            table.setModel(m);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            table.setModel(m);
        }
    }
}
