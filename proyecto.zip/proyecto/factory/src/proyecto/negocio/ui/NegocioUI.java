package proyecto.negocio.ui;

import javax.swing.*;
import java.awt.*;
import java.util.function.Supplier;

import factory.database.*;
import proyecto.negocio.ui.*;

public class NegocioUI extends JFrame {

    private Supplier<Database> currentFactorySupplier;

    public NegocioUI() {
        setTitle("Negocio - UI");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        // Base de datos por defecto: SQLite
        currentFactorySupplier = () -> new SQLiteDatabase("jdbc:sqlite:baseproduccion.db");

        // Barra de menú
        JMenuBar menuBar = new JMenuBar();
        JMenu menuDB = new JMenu("Base de Datos");

        JMenuItem mysql = new JMenuItem("MySQL");
        mysql.addActionListener(e -> {
            currentFactorySupplier = () -> new MySQLDatabase(
                    "jdbc:mysql://172.30.16.148:3306/AndresB",
                    "u67001549",
                    "12345"
            );
            JOptionPane.showMessageDialog(this, "Conectado a MySQL");
        });

        JMenuItem pg = new JMenuItem("PostgreSQL");
        pg.addActionListener(e -> {
            currentFactorySupplier = () -> new PostgresDatabase(
                    "jdbc:postgresql://172.30.16.153:5432/AndresB",
                    "67001549",
                    "1234"
            );
            JOptionPane.showMessageDialog(this, "Conectado a PostgreSQL");
        });

        JMenuItem sqlite = new JMenuItem("SQLite");
        sqlite.addActionListener(e -> {
            currentFactorySupplier = () -> new SQLiteDatabase("jdbc:sqlite:baseproduccion.db");
            JOptionPane.showMessageDialog(this, "Conectado a SQLite");
        });

        menuDB.add(mysql);
        menuDB.add(pg);
        menuDB.add(sqlite);
        menuBar.add(menuDB);
        setJMenuBar(menuBar);

        // Pestañas principales
        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Usuarios", new UsuarioPanel(currentFactorySupplier));
        tabs.add("Productos", new ProductoPanel(currentFactorySupplier));
        tabs.add("Ventas", new VentaPanel(currentFactorySupplier));
        tabs.add("Reportes", new ReportePanel(currentFactorySupplier));

        add(tabs, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            NegocioUI ui = new NegocioUI();
            ui.setVisible(true);
        });
    }
}
