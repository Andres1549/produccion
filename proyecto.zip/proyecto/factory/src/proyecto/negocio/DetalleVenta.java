package proyecto.negocio;
import proyecto.producto.Producto;
public class DetalleVenta { private Producto producto; private int cantidad; public DetalleVenta(){} public DetalleVenta(Producto p,int c){this.producto=p;this.cantidad=c;} public Producto getProducto(){return producto;} public int getCantidad(){return cantidad;} public void setProducto(Producto p){this.producto=p;} public void setCantidad(int c){this.cantidad=c;} }
