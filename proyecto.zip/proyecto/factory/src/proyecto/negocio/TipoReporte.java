package proyecto.negocio;
public enum TipoReporte { VENTAS, INVENTARIO, USUARIOS }
