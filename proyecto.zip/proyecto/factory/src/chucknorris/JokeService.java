// Interfaz que la aplicación espera usar
package chucknorris;
public interface JokeService {
    String getJoke();
}
