package factory.database;

public class PostgresFactory extends DatabaseFactory {
    @Override
    public Database createDatabase(String url) {
        return new PostgresDatabase(url, "67001549", "12345");
    }
}
