package factory.database;

public class MySQLFactory extends DatabaseFactory {
    @Override
    public Database createDatabase(String url) {
        return new MySQLDatabase(url, "u67001549", "12345");
    }
}
