package factory.database;

import java.sql.Connection;

public interface Database {
    Connection connect();
}
