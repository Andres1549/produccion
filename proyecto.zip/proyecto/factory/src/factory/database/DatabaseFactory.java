package factory.database;

public abstract class DatabaseFactory {
    public abstract Database createDatabase(String url);

    }

